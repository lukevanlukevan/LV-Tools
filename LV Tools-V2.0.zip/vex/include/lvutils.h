float rand_range(float arg1; float arg2; float arg3)
{
    return fit01(rand(arg1), arg2, arg3);
}